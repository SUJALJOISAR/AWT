import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import db from './config/db';
import Book from './models/book';
import bookController from './src/bookController';

const app = express();

app.use(bodyParser.json());
app.use(cors());

app.get('/', (req, res) => {
    res.send('Hello World!');
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

app.post('/books', bookController.createBook);
app.get('/books', bookController.getAllBooks);
app.get('/books/:id', bookController.getBookById);
app.put('/books/:id', bookController.updateBookById);
app.delete('/books/:id', bookController.deleteBookById);

// const express = require('express');
const router = express.Router();

router.get('/', function(req, res) {
    res.send('Library Home Page');
});

module.exports = router;
